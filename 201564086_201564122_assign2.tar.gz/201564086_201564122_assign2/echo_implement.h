#include <stdio.h>
#include <stdlib.h>


int run_echo(char **);
void checkEcho(char *);
char* addToPrintBuf(char *, char , int *);
char* echoOutLine(int *, char *); // Pre Defs
